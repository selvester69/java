function displaySalary(){
	
	var sal=empForm.empSalary.value;
	//alert(sal);
	document.getElementById('divSal').innerHTML='<b>'+sal+'</b>';
	
}

function showSal(){
	var sal=document.getElementById('esal').value;
	document.getElementById('divSal').innerHTML='<b>'+sal+'</b>';
	//alert(e1.empSalary.value);
}

function searchEmployee(){
	
	var eid=empForm.empId.value;
	//alert(eid);
	
	//AJAX Request
	
	//Ajax Code 
	var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4) {
            var data = xhr.responseText;
             document.getElementById('result').innerHTML=data;
        }
    }
    xhr.open('GET', 'FindEmpServlet?empId='+eid  , true);
  
    xhr.send(null);
	
}