package com.flp.pms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.Sub_Category;
import com.flp.pms.domain.Supplier;


public interface IProductDao {
	
	public Connection getConnection();
	
	public List<Category> getAllCategory();

	public List<Sub_Category> getAllSubCategory();

	public List<Supplier> getAllSupplier();

	public List<Discount> getAllDiscounts();

	public void addProduct(Product product);

	public List<Product> getAllproductlist();
	
	public boolean updateProductName(String name, int productId);
	
	public boolean updateProductDescription(String description, int productId);
	
	public boolean updateProductManufacturing(java.util.Date manufacturingDate, int productId);
	
	public boolean updateProductExpiryDate(java.util.Date expiryDate, int productId);
	
	public boolean updateProductMRP(double mrp, int productId);
	
	public boolean updateProductQuantity(int quantity, int productId);
	
	public boolean updateProductRating(float rating, int productId);
	
	public boolean updateProductCategory(Category category, int productId);
	
	public boolean updateProductSupplier(Supplier supplier, int productId);

	public boolean deleteProduct(int deteleProductId);
	
	public Category getCategory(int categoryId);
	
	public Sub_Category getSubCategory(int subCategory);
	
	public Supplier getSupplier(int supplierId);
	
	public List<Discount> getProductDiscount(int productId);
}
