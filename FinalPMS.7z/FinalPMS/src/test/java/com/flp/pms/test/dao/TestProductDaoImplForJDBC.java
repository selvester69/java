package com.flp.pms.test.dao;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplForJDBC;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Sub_Category;
import com.flp.pms.domain.Supplier;

public class TestProductDaoImplForJDBC {
IProductDao daoImpl = new ProductDaoImplForJDBC();
	
	@Test
	public void testGetAllCategories(){
		List<Category> categories = daoImpl.getAllCategory();
		for(Category category:categories)
			System.out.println(category);
		
		assertEquals(5, categories.size());
	}
	
	@Test
	public void testGetAllSubCategory(){
		List<Sub_Category> s = daoImpl.getAllSubCategory();
		for(Sub_Category sub:s)
			System.out.println(sub);
		assertEquals(17, s.size());
	}
	
	@Test
	public void testGetAllSuppler(){
		List<Supplier> s = daoImpl.getAllSupplier();
		for(Supplier sup:s)
			System.out.println(sup);
		assertEquals(6, s.size());
	}
	
	@Test
	public void testGetAllDiscount(){
		List<Discount> s = daoImpl.getAllDiscounts();
		for(Discount dis:s)
			System.out.println(dis);
		assertEquals(5, s.size());
	}
	
	
	
	
}
