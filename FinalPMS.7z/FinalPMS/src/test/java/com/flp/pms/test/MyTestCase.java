package com.flp.pms.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.flp.pms.domain.Product;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;
import com.flp.pms.view.UserInteraction;

public class MyTestCase{
	IProductService iProductService;
	UserInteraction userInteraction;
	
	
	@Before
	public void createServiceIntance(){
		System.out.println("TestCase Started");
		iProductService = new ProductServiceImpl();
		userInteraction = new UserInteraction();
	}
	
	
	@Test
	public void testgetProductName() {
		String s = userInteraction.getProductName();
		assertEquals(s, "Abhijeet");
		
		
	}
	@Test
	public void testgetSupplierName() {
		String s = userInteraction.getSupplierName();
		assertEquals(s, "Abhijeet");
		
		
	}
	
	

}
