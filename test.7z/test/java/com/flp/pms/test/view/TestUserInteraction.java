package com.flp.pms.test.view;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Scanner;

import org.junit.Assert;
import org.junit.Test;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplForJDBC;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Sub_Category;
import com.flp.pms.domain.Supplier;
import com.flp.pms.view.UserInteraction;

public class TestUserInteraction {
		UserInteraction ui = new UserInteraction();
		IProductDao dao = new ProductDaoImplForJDBC();
	
		@Test
	public void AddProduct(List<Category> categories, List<Sub_Category> sub_Categories, List<Discount> discounts,
			List<Supplier> suppliers){
	}
	
		@Test
		public void getCategory(List<Category> categories){
			
		}
		
		@Test
		public void getSupplier(){
			List<Supplier> suppliers = dao.getAllSupplier();
			boolean flag = false;
			Scanner sc = new Scanner(System.in);
			Supplier supplier = null;
			int choice;
			do {

				System.out.println("choose supplier id:");

				for (Supplier supplier1 : suppliers) {
					System.out.print(supplier1.getSupplier_id() + "\t");
					System.out.print(supplier1.getFirst_name() + "\t");
					System.out.print(supplier1.getLast_name() + "\t");
					System.out.print(supplier1.getAddress() + "\t");
					System.out.print(supplier1.getCity() + "\t");
					System.out.print(supplier1.getState() + "\t");
					System.out.println(supplier1.getPincode());

				}

				choice = sc.nextInt();
				// validating the category
				for (Supplier supplier1 : suppliers) {
					if (choice == supplier1.getSupplier_id()) {
						supplier = supplier1;
						flag = true;
						break;
					}
				}

				if (!flag)
					System.out.println("please choose valid category id:");

			} while (!flag);
			assertEquals(1,"");
		
		}
	
	
}
