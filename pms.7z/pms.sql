CREATE DATABASE productManagementSystem;

CREATE TABLE discount(discountId INT PRIMARY KEY AUTO_INCREMENT,discountName VARCHAR(200), description VARCHAR(500),
		discount_percentage DECIMAL(4,2),
		validThru DATE );
		


CREATE TABLE supplier( supplierId INT PRIMARY KEY AUTO_INCREMENT ,firstName VARCHAR(50),lastName VARCHAR(50),
		address VARCHAR(100),city VARCHAR(50),state VARCHAR(30),
		pincode VARCHAR(10),contactno VARCHAR(15));	

CREATE TABLE  Category( category_Id INT PRIMARY KEY AUTO_INCREMENT,category_Name VARCHAR(50),
		description VARCHAR(50));
		
CREATE TABLE SubCategory( sub_category_Id INT  AUTO_INCREMENT,
		sub_category_Name VARCHAR(50),
		category_Id INT ,PRIMARY KEY (sub_Category_Id),
		FOREIGN KEY (category_Id) REFERENCES category(category_Id));
		
		
		
CREATE TABLE Product( productId INT AUTO_INCREMENT ,productName VARCHAR(50),
			description VARCHAR(50), manufacturing_date DATE,
			expiry_date DATE , max_retail_price DOUBLE(8,2),productmanagmentsystemproductmanagmentsystemproductmanagmentsystemproductmanagmentsystemproductmanagmentsystemproductmanagmentsystemcapdb
			category_Id INT ,sub_category_Id INT ,supplierId INT,
			discountId INT ,  quantity INT,  ratings DECIMAL(2,1),
			PRIMARY KEY (productId),
			FOREIGN KEY (category_Id) REFERENCES category(category_Id),
			FOREIGN KEY (sub_category_Id) REFERENCES subcategory(sub_category_Id),
			FOREIGN KEY (supplierId) REFERENCES supplier(supplierId),
			FOREIGN KEY (discountId) REFERENCES discount(discountId));
			
DESC product;
DESC category;
DESC discount;
DESC subcategory;
DESC supplier;

INSERT INTO discount(discountName,description,discount_percentage,validThru) VALUES('Mega Offer', 'Mega offer From Jan to Feb', 12.4,'2009-04-23');
INSERT INTO discount(discountName,description,discount_percentage,validThru) VALUES('Dewali Offer', 'Dewali offer ', 12.4, '2018-04-23');
INSERT INTO discount(discountName,description,discount_percentage,validThru) VALUES('New Year Offer','New Year offer ', .50,'2020-04-23');
INSERT INTO discount(discountName,description,discount_percentage,validThru) VALUES("X'Mas Offer", 'Xmas offer ', .55, '2019-04-23');
INSERT INTO discount(discountName,description,discount_percentage,validThru) VALUES('Pongal Offer', 'Pongal offer', 12.78, '2017-04-23');

SELECT * FROM discount;

INSERT INTO supplier(firstName,lastName,address,city,state,pincode,contactno) VALUES ( 'Tom', 'Jerry', 'North Avvenue', 'Chennai', 'Tamil Nadu', '600041', '6576575');
INSERT INTO supplier(firstName,lastName,address,city,state,pincode,contactno) VALUES ('Jack', 'Thomson', 'South Avvenue', 'Chennai', 'Tamil Nadu', '600341', '78987978');
INSERT INTO supplier(firstName,lastName,address,city,state,pincode,contactno) VALUES ( 'Kamal', 'Emi', 'West Avvenue', 'Chennai', 'Tamil Nadu','600001', '787665765');
INSERT INTO supplier(firstName,lastName,address,city,state,pincode,contactno) VALUES ( 'Annie', 'Kenn', 'EAST Avvenue', 'Pune', 'Maharastra', '600121', '5464565645');
INSERT INTO supplier(firstName,lastName,address,city,state,pincode,contactno) VALUES ( 'Vimal', 'Desai', '7th Avvenue', 'Pune', 'Maharastra', '600121', '87686787');
INSERT INTO supplier(firstName,lastName,address,city,state,pincode,contactno) VALUES ( 'Bimal', 'Singh', '12th Avvenue', 'Pune', 'Maharastra', '600121','12456767');

SELECT * FROM supplier;

INSERT INTO category(category_Name,description) VALUES('Electronics', 'Electronic Items');
INSERT INTO category(category_Name,description) VALUES('"Clothing', 'All Cloth Varity');
INSERT INTO category(category_Name,description) VALUES('"Health&Care', 'Health And Hospitality');
INSERT INTO category(category_Name,description) VALUES('HouseHolds', 'HouseHold Items');
INSERT INTO category(category_Name,description) VALUES('Sports', 'Games related Items');

SELECT * FROM category;

INSERT INTO subcategory (sub_category_Name ,category_Id) VALUES('mobile',1 );
INSERT INTO subcategory (sub_category_Name ,category_Id) VALUES('Data Storage',1 );
INSERT INTO subcategory (sub_category_Name ,category_Id) VALUES('Power bank',1 );

INSERT INTO subcategory (sub_category_Name ,category_Id) VALUES('formals',2 );
INSERT INTO subcategory (sub_category_Name ,category_Id) VALUES('casuvals',2 );
INSERT INTO subcategory (sub_category_Name ,category_Id) VALUES('sports wear',2 );

INSERT INTO subcategory (sub_category_Name ,category_Id) VALUES('Diabetic Metre',3 );
INSERT INTO subcategory (sub_category_Name ,category_Id) VALUES('Blood Pressure Metre',3 );
INSERT INTO subcategory (sub_category_Name ,category_Id) VALUES('Diabetic Shoes',3 );

INSERT INTO subcategory (sub_category_Name ,category_Id) VALUES('Dining Sets',4 );
INSERT INTO subcategory (sub_category_Name ,category_Id) VALUES('Cooker',4 );
INSERT INTO subcategory (sub_category_Name ,category_Id) VALUES('Knife',4 );
INSERT INTO subcategory (sub_category_Name ,category_Id) VALUES('Glasses',4 );

INSERT INTO subcategory (sub_category_Name ,category_Id) VALUES('Bat',5 );
INSERT INTO subcategory (sub_category_Name ,category_Id) VALUES('racquet',5 );
INSERT INTO subcategory (sub_category_Name ,category_Id) VALUES('shuttlecock',5 );
INSERT INTO subcategory (sub_category_Name ,category_Id) VALUES('ball',5 );

SELECT * FROM subcategory;


INSERT INTO product
	(productName,description,manufacturing_date,expiry_date,max_retail_price,category_Id,
	  supplierId,discountId,quantity,ratings)
	 VALUES();
