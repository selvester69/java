package com.flp.pms.view;

import java.util.Scanner;

import com.flp.pms.domain.Product;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;

public class BootClass {

	public static void main(String[] args) {
		menuSelection();

	}

	public static void menuSelection() {

		Scanner sc = new Scanner(System.in);
		int option;
		String choice = null;
		IProductService iProductService = new ProductServiceImpl();
		UserInteraction userInteraction = new UserInteraction();
		do {
			System.out.println("1.Create Product");
			System.out.println("2.Modify Product");
			System.out.println("3.Remove Product");
			System.out.println("4.View All Product");
			System.out.println("5.Search Product");
			System.out.println("6.Exit");
			System.out.println("enter your option");
			option = sc.nextInt();

			switch (option) {

			case 1:
				Product product = userInteraction.AddProduct(iProductService.getAllCategory(),
						iProductService.getAllSubCategory(), iProductService.getAllDiscounts(),
						iProductService.getAllSupplier());
				iProductService.addProduct(product);
				break;
				
				
			case 2://modify
			case 3:userInteraction.deleteProduct();
			case 4:
				/*System.out.println("All products list");*/
				System.out.println(iProductService.getAllProducts());
				//userInteraction.printAllProducts(iProductService.getAllProducts());
				break;
			case 5:
				String searchChoiceRepeat=null;
				do{
				System.out.println("1. Search Product by name");
				System.out.println("2. Search Product by Producer(Supplier)");
				System.out.println("3. Search Product by Category");
				System.out.println("4. Search Product by Sub-Category");
				System.out.println("5. Search Product by Rating");
				
				int searchChoice = sc.nextInt();
				switch (searchChoice) {
				case 1:
					String name = userInteraction.getProductName();
					userInteraction.searchedProduct(iProductService.searchByProductName(name));
					break;
				case 2:
					String supplierName = userInteraction.getSupplierName();
					userInteraction.searchedProduct(iProductService.searchBySupplierName(supplierName));
					break;
				case 3:
					String categoryName = userInteraction.getCategoryName();
					userInteraction.searchedProduct(iProductService.searchByProductCategory(categoryName));
					break;
				case 4:
					String subCategoryName = userInteraction.getSubCategoryName();
					userInteraction.searchedProduct(iProductService.searchByProductSubCategory(subCategoryName));
					break;
				case 5:
					float rating = userInteraction.getRatings();
					userInteraction.searchedProduct(iProductService.searchByProductRating(rating));
					break;
				default:
					break;
				}
				System.out.println("You wish to continue?[Y|N]");
				searchChoiceRepeat=sc.next();
				}while(searchChoiceRepeat.charAt(0) == 'y' || searchChoiceRepeat.charAt(0) == 'Y');
				break;

			case 6:
				System.exit(0);
				break;

			}
			System.out.println("You wish to continue?[Y|N]");
			choice = sc.next();
		} while (choice.charAt(0) == 'y' || choice.charAt(0) == 'Y');
	}

}
