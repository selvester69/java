package org.flp.pms.test.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.flp.pms.domain.Category;
import com.flp.pms.service.ProductServiceImpl;
import com.flp.pms.view.UserInteraction;

public class ServiceTest {
	
	ProductServiceImpl pService;
	@Before
	public void createServiceIntance(){
		pService = new ProductServiceImpl();
		
	}
	
	@Test
	public void countAllCategories() {
		List<Category> categories = pService.getAllCategory();
		assertEquals(5, categories.size());
	
	}
	

}
