package org.cap.demo;

import java.sql.Timestamp;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

import com.sun.java_cup.internal.runtime.Scanner;
import com.sun.java_cup.internal.runtime.Symbol;

public class TestClass {
	
	public static void main(String[] args) {
		
		
		
		AnnotationConfiguration config = new AnnotationConfiguration();
		config.addAnnotatedClass(Employee.class);
		config.configure();
		
		
	//	new SchemaExport(config).create(true, true);
		
		
		//Session Factory
		SessionFactory sessFactory = config.buildSessionFactory();
		
		
		//add values
		//Employee emp = new Employee("Abhijeet", "Srivastava", 2999, new Date(), new Date(), "rakesh@mail.com");
		
		//Begin and Save transaction
		/*Session session = sessFactory.openSession();
		org.hibernate.Transaction trans = session.beginTransaction();
		session.save(emp);*/
		
		Session session = sessFactory.openSession();
		org.hibernate.Transaction trans = session.beginTransaction();
		
		
		
		trans.commit();
		session.close();

	}

}
