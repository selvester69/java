package org.cap.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class TestClass1 {

	public static void main(String[] args) {
		AnnotationConfiguration config=new AnnotationConfiguration();
		config.addAnnotatedClass(Student.class);
		config.configure();
		
		//To Recreate Schema everyTime
		new SchemaExport(config).create(true, true);
		
		
		SessionFactory sessfactory=config.buildSessionFactory();
		Session session=sessfactory.openSession();
		session.getTransaction().begin();
		StudentID studentID=new StudentID(1001, 111);
		Student student=new Student(studentID, "Jack", "Java");
		
		session.save(student);
		
		session.getTransaction().commit();
		
		session.close();

	}

}
