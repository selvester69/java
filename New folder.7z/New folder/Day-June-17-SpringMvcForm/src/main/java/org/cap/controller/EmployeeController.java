package org.cap.controller;

import javax.validation.Valid;

import org.cap.pojo.Employee;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EmployeeController {
	
	@RequestMapping("/employee")
	public ModelAndView showEmployeeForm(){
		return new ModelAndView("EmpForm", "emp", new Employee());
	}
	
	@RequestMapping(value="/saveEmployee",method=RequestMethod.POST)
	public String saveEmployeeDetails(@Valid @ModelAttribute("emp") Employee employee,
			BindingResult result){
		if(result.hasErrors()){
			return "EmpForm";
		}else
		{
		System.out.println(employee);
		return "result";
		}
	}

}
