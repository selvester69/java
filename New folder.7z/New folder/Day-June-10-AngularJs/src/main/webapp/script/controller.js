app.controller("myController",function($scope){
	$scope.greetings="Hello! "
	$scope.firstName="TOM";
	
	
	 $scope.greetUser=function(){
		return $scope.greetings+" " + $scope.firstName;
		
	};
	
});

app.controller("myProduct",function($scope){
	
	$scope.amount=0;
	
	$scope.calculateAmt=function(){
		
		$scope.amount=($scope.qty*$scope.price)-($scope.qty * $scope.price * $scope.discount)/100;
		
		
	}
	
	
	
	
});