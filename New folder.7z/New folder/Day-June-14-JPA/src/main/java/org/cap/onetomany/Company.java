package org.cap.onetomany;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Company {
	
	@Id
	private int compId;
	private String compName;
	
	@OneToMany(targetEntity=Employee.class,mappedBy="company",
			cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private List<Employee> employees;
	
	public Company(){}
	
	
	public Company(int compId, String compName) {
		super();
		this.compId = compId;
		this.compName = compName;
		
	}

	public Company(int compId, String compName, List<Employee> employees) {
		super();
		this.compId = compId;
		this.compName = compName;
		this.employees = employees;
	}

	public int getCompId() {
		return compId;
	}

	public void setCompId(int compId) {
		this.compId = compId;
	}

	public String getCompName() {
		return compName;
	}

	public void setCompName(String compName) {
		this.compName = compName;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	@Override
	public String toString() {
		return "Company [compId=" + compId + ", compName=" + compName + ", employees=" + employees + "]";
	}
	
	

}
