package org.cap.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class MyJavaConfig {
	
	@Bean
	@Scope("prototype")
	public Customer getCustomer(){
		return new Customer(1001, "Jack", 12000);
	}
	

}
