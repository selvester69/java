package org.cap.jdbc.demo;

import java.util.List;

import org.cap.jdbc.dao.EmployeeDaoImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BootClass {

	public static void main(String[] args) {
		
		
		ApplicationContext context=new ClassPathXmlApplicationContext("myBeans.xml");
		
		EmployeeDaoImpl empDao=(EmployeeDaoImpl)context.getBean("employeeDaoImpl");
		/*Company company=new Company();
		company.setCompanyId(1003);
		
		Employee emp=new Employee(190, "Kamal", 45000,company);
		
		empDao.createEmployee(emp);*/
		
		
	/*	List<Employee> emps=empDao.getAllEmployees();
		
		for(Employee emp:emps)
			System.out.println(emp);*/
		
		String ename=empDao.findEmployee(190);
		
		System.out.println(ename);
		
		
	}

}
