package org.cap.jdbc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.cap.jdbc.demo.Company;
import org.cap.jdbc.demo.Employee;
import org.springframework.jdbc.core.RowMapper;

public class EmployeeRow implements RowMapper<Employee> {

	@Override
	public Employee mapRow(ResultSet rs, int count) throws SQLException {
		
		Employee employee=new Employee();
		
		employee.setEmpId(rs.getInt("empId"));
		employee.setEmpName(rs.getString("empName"));
		employee.setSalary(rs.getDouble("salary"));
		Company company=new Company();
		company.setCompanyId(rs.getInt("Compy_Id"));
		employee.setCompany(company);
		
		return employee;
	}

}
