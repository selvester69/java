package org.cap.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		ApplicationContext context=new AnnotationConfigApplicationContext(MyJavaConfig.class);
		
		Customer customer= context.getBean(Customer.class);
		Customer customer1= context.getBean(Customer.class);
		
		customer.setCustName("Tom");
		
		System.out.println(customer);
		System.out.println(customer1);
	}

}
