package org.cap.jdbc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.cap.jdbc.demo.Company;
import org.springframework.jdbc.core.RowMapper;

public class CompanyRow implements RowMapper<Company>{

	@Override
	public Company mapRow(ResultSet rs, int row) throws SQLException {
		
		Company company=new Company();
		
		company.setCompanyId(rs.getInt("compId"));
		company.setCompanyName(rs.getString("compName"));
		
		
		return company;
	}

}
