package org.cap.demo.util;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class MyCollection {
	
	private List<String> names;
	private Set<Integer> numbers;
	private Map<Integer, String> datas;
	private Properties myProperty;

	public MyCollection(){}
	
	
	
	public Set<Integer> getNumbers() {
		return numbers;
	}



	public void setNumbers(Set<Integer> numbers) {
		this.numbers = numbers;
	}



	public Map<Integer, String> getDatas() {
		return datas;
	}



	public void setDatas(Map<Integer, String> datas) {
		this.datas = datas;
	}



	public List<String> getNames() {
		return names;
	}

	public void setNames(List<String> names) {
		this.names = names;
	}
	
	

	public Properties getMyProperty() {
		return myProperty;
	}



	public void setMyProperty(Properties myProperty) {
		this.myProperty = myProperty;
	}



	@Override
	public String toString() {
		return "MyCollection [names=" + names + "]";
	}
	
	

}
