package com.flp.pms.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.flp.pms.domain.Discount;

public class DiscountRow implements RowMapper<Discount> {

	@Override
	public Discount mapRow(ResultSet rs, int count) throws SQLException {
		Discount discount = new Discount();
		discount.setDiscount_id(rs.getInt("discount_id"));
		discount.setDiscount_name(rs.getString("discount_name"));
		discount.setDescription(rs.getString("description"));
		discount.setDiscount_percentage(rs.getDouble("discount_percentage"));
		discount.setValid_thru(rs.getDate("valid_thru"));
		return discount;
	}

}
