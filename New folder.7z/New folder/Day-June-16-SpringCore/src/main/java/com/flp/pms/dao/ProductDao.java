package com.flp.pms.dao;

import java.util.List;

import com.flp.pms.domain.Product;

public interface ProductDao {
	public void createProduct(Product product);
	
	public void deleteProduct(int productId);
	
	public List<Product> getAllProducts();
	

}
