package com.flp.pms.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.cap.jdbc.demo.Company;
import org.springframework.jdbc.core.RowMapper;

import com.flp.pms.domain.Category;

public class CategoryRow implements RowMapper<Category> {

	@Override
	public Category mapRow(ResultSet rs, int count) throws SQLException {
Category category  = new Category();
category.setCategory_id(rs.getInt("category_id"));
category.setCategory_name(rs.getString("category_name"));
category.setDescription(rs.getString("description"));
		return category;
	}

}
