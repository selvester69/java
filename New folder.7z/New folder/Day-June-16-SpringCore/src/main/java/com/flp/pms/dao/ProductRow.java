package com.flp.pms.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.cap.jdbc.demo.Employee;
import org.springframework.jdbc.core.RowMapper;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.Sub_Category;
import com.flp.pms.domain.Supplier;

public class ProductRow implements RowMapper<Product> {

	@Override
	public Product mapRow(ResultSet rs, int count) throws SQLException {
	Product product=new Product();
	product.setProduct_id(rs.getInt("product_id"));
	product.setProduct_name(rs.getString("product_name"));
	product.setQuantity(rs.getInt("quantity"));
	product.setDescription(rs.getString("description"));
	product.setManufacturing_date(rs.getDate("manufacturing_ate"));
	product.setExpiry_date(rs.getDate("expir_date"));
	product.setMaximum_retail_price(rs.getDouble("max_retail_price"));
	Category category = new Category();
	category.setCategory_id(rs.getInt("category_id"));
	product.setCategory(category);
	
	Sub_Category sub = new Sub_Category();
	sub.setSub_categoryId(rs.getInt("sub_categoryId"));
	product.setSub_Category(sub);
	
	Supplier supplier = new Supplier();
	supplier.setSupplier_id(rs.getInt("supplier_id"));
	product.setSupplier(supplier);
	
		return product;
	}

}
