package com.flp.pms.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Sub_Category;

public class Sub_CategoryRow implements RowMapper<Sub_Category> {

	@Override
	public Sub_Category mapRow(ResultSet rs, int count) throws SQLException {
		Sub_Category sub_Category = new Sub_Category();
		sub_Category.setSub_categoryId(rs.getInt("sub_categoryId"));
		sub_Category.setSub_category_name(rs.getString("sub_category_name"));
		Category category = new Category();
		category.setCategory_id(rs.getInt("category_id"));
		sub_Category.setCategory(category);
		
		return sub_Category;
	}

}
