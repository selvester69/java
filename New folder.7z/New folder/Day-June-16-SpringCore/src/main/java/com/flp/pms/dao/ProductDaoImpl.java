package com.flp.pms.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.flp.pms.domain.Product;

public class ProductDaoImpl implements ProductDao {

	private JdbcTemplate jdbcTemp;
	private DataSource dataSource;
	
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemp=new JdbcTemplate(dataSource);
	}
	
	@Override
	public void createProduct(Product product) {
		String sql="insert into product values(?,?,?,?,?,?,?,?,?,?)";
		jdbcTemp.update(sql, new Object[]{product.getProduct_name(),
				product.getDescription(),product.getManufacturing_date(),product.getExpiry_date(),
				product.getMaximum_retail_price(),product.getRatings(),product.getQuantity(),
				product.getCategory().getCategory_id(),product.getSub_Category().getSub_categoryId(),
				product.getSupplier().getSupplier_id()
		});
		//String sql2 = "insert into product_discount "
		
		System.out.println("Success");
	}

	@Override
	public void deleteProduct(int productId) {
		String sql= "delete from product where product_id=? ";
		String sql2 = "delete from product_discount where product_id=?";
		jdbcTemp.update(sql, new Object[]{productId});
		jdbcTemp.update(sql2, new Object[]{productId});
		
	}

	@Override
	public List<Product> getAllProducts() {
		
		
		return null;
	}

}
