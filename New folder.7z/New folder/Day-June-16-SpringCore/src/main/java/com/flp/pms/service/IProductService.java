package com.flp.pms.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.Sub_Category;
import com.flp.pms.domain.Supplier;


public interface IProductService {

	List<Category> getAllCategory();

	List<Sub_Category> getAllSubCategory();

	List<Supplier> getAllSupplier();

	List<Discount> getAllDiscounts();

	public void createProduct(Product product);

	public Product searchByProductName(String productName);
	
	public Product searchBySupplierName(String SupplierName);
	
	public Product searchByProductCategory(String category);
	
	public Product searchByProductSubCategory(String subCategory);
	
	public Product searchByProductRating(float rating);

	public Product searchByProductId(int productid);

	public List<Product> getAllproductlist();
	
	public boolean updateProductDescription(String description, int productId);

	public boolean updateProductName(String name, int productId);

	public boolean updateProductManufacturing(Date manufacturingDate, int productId);

	public boolean updateProductExpiryDate(Date expiryDate, int productId);

	public boolean updateProductMRP(double mrp, int productId);

	public boolean updateProductQuantity(int quantity, int productId);

	public boolean updateProductRating(float rating, int productId);

	public boolean updateProductCategory(Category category, int productId);

	public boolean updateProductSupplier(Supplier supplier, int productId);

	public boolean deleteproduct(int deteleProductId);

	

	

}
