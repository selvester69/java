package com.flp.pms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Category;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;
import com.google.gson.Gson;


public class CategoryServlets extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json");
		
		PrintWriter out=response.getWriter();
		
		IProductService iProductService = new ProductServiceImpl();
		List<Category> categories= iProductService.getAllCategory();
		
		Gson myJson=new Gson();
		
		String categoryJson = myJson.toJson(categories);
		
		out.println(categoryJson);
	}

	
}
