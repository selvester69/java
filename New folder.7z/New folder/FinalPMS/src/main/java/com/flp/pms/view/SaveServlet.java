package com.flp.pms.view;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.Sub_Category;
import com.flp.pms.domain.Supplier;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;


public class SaveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IProductService iProductService = new ProductServiceImpl();
		//Directly call productobj and store these variable
		Product product = new Product();
		Category category = new Category();
		Sub_Category sub_Category = new Sub_Category();
		Discount discount = null;
		Supplier supplier = new Supplier();
		List<Discount> discounts = new ArrayList<Discount>();
		
		String name= request.getParameter("productName");
		product.setProduct_name(name);
		
		String description = request.getParameter("description");
		product.setDescription(description);
		
		SimpleDateFormat format = new SimpleDateFormat("dd-mmm-yyyy");
		String manDate = request.getParameter("ManufacturingDate");
		String expDate = request.getParameter("ExpiryDate");
		Date manufacturingDate=null;
		Date expiryDate=null;
		try {
			manufacturingDate = format.parse(manDate);
			expiryDate = format.parse(expDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		product.setManufacturing_date(manufacturingDate);
		product.setExpiry_date(expiryDate);
		
		double price= Double.parseDouble(request.getParameter("mrp"));
		product.setMaximum_retail_price(price);
		
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		product.setQuantity(quantity);
		
		float rating = Float.parseFloat(request.getParameter("rating"));
		product.setRatings(rating);
		
		int categoryId = Integer.parseInt(request.getParameter("Category"));
		category.setCategory_id(categoryId);
		product.setCategory(category);
		
		int subcategoryId = Integer.parseInt(request.getParameter("Subcategory"));
		sub_Category.setSub_categoryId(subcategoryId);
		product.setSub_Category(sub_Category);
		
		int supplierId = Integer.parseInt(request.getParameter("Supplier"));
		supplier.setSupplier_id(supplierId);
		product.setSupplier(supplier);
		
		String[] discountId = request.getParameterValues("Discount");
		for(int i=0;i<discountId.length;i++){
			discount=new Discount();
			discount.setDiscount_id(Integer.parseInt(discountId[i]));
			discounts.add(discount);
		}
		product.setDiscounts(discounts);
		
		iProductService.addProduct(product);
		
	}

}
